Attached is the 'project_Anuj.zip' zipped folder with everything within it. Included is ALL the flight routes with the order of by day and time '3.1.19-4.9.19.txt' using the Excel file 'majorAirportsOnly.xlsx' in the 'python' folder. 

If you want to use only March 1st flight (in which I was going to do at first), the text file is saved in the folder 'txt_files' as the text file of  '3-1-19.txt'. 

Currently the JavaScript ('flightanimation.js') has the '3.1.19-4.9.19' text file in it, but it you would like to change it to view only March 1st flights then replace the origin and destination airport code located in the beginning of the 'flightanimation.js' with the text in the text file '3-1-19'.

How to view animation on local server:
1) Unzip 'cloud' folder
2) Open command prompt
3) Change the directory to the cloud folder
4) Type 'python -m http.server'
5) Go to your browser and type in 'http://localhost:8000/'

How to view animation on the cloud:
1) https://sodium-dynamo-252117.appspot.com/


^^^Created with Google Cloud Platform - App Engine