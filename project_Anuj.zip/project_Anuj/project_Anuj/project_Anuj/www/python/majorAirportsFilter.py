#Filter out flight schedule so that only routes between major cities remain.

import pandas as pd

airports = "ATL MAD SFO LAX SEA ORD JFK HNL IST AMS CDG LHR NRT HKG SIN IAH EWR ZRH DMK DEL GIG JNB IAD DCA"
airports = airports.split(" ")

#open excel file as dataframe
flights = pd.read_excel('flightSchedDataFrame.xlsx')
flightsFiltered = flights.copy(deep=True)

flightsFiltered = flightsFiltered[flightsFiltered['ArrivalCity'].isin(airports)]
flightsFiltered = flightsFiltered[flightsFiltered['DepartCity'].isin(airports)]

flightsFiltered.to_excel("majorAirportsOnly.xlsx", sheet_name = "Flight Schedule (Major cities)")